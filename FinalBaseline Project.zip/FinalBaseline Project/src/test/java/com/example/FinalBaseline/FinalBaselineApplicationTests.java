package com.example.FinalBaseline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalBaselineApplicationTests {

	@Test
	void contextLoads() {
	}

}

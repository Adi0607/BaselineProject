package com.example.FinalBaseline;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.logging.Logger;

@Component
public class JiraClient {

    static final Logger logger = Logger.getLogger(JiraClient.class.getName());

    @Value("${jira.url}")
    private String URL;

    @Value("${jira.username}")
    private String USERNAME;

    @Value("${jira.api_token}")
    private String API_TOKEN;

    private final String ENCODED_AUTH;
    private final ObjectMapper OBJECT_MAPPER;

    public JiraClient(ObjectMapper objectMapper) {
        this.OBJECT_MAPPER = objectMapper;
        this.ENCODED_AUTH = Base64.getEncoder().encodeToString((USERNAME + ":" + API_TOKEN).getBytes(StandardCharsets.UTF_8));
    }

    public HttpResponse<String> sendJiraRequest(JiraSearchRequest searchRequest) throws Exception {
        String jsonBody = createRequestBody(searchRequest);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL))
                .header("Content-Type", "application/json")
                .header("Authorization", "Basic " + ENCODED_AUTH)
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        logger.info("Response Code: " + response.statusCode());
        logger.info("Response Body: " + response.body());

        return response;
    }

    private String createRequestBody(JiraSearchRequest searchRequest) throws Exception {
        String escapedJql = searchRequest.getJql().replace("\"", "\\\"");
        return OBJECT_MAPPER.writeValueAsString(Map.of(
                "jql", escapedJql,
                "startAt", searchRequest.getStartAt(),
                "maxResults", searchRequest.getMaxResults()
        ));
    }
}

package com.example.FinalBaseline;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.ReplaceOptions;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class MongoConnection {

    private static final String DATABASE = "sampleticketdb";
    private static final Logger LOGGER = Logger.getLogger(MongoConnection.class.getName());

    static MongoDatabase database;

    @Autowired
    public MongoConnection(MongoClient mongoClient) {
        this.database = mongoClient.getDatabase(DATABASE);
    }

    public static void insertUser(String userId, String name, String email) {
        try {
            MongoCollection<Document> collection = database.getCollection("users");
            Document doc = new Document("userId", userId)
                    .append("name", name)
                    .append("email", email);
            collection.replaceOne(Filters.eq("userId", userId), doc, new ReplaceOptions().upsert(true));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error inserting user: " + userId, e);
        }
    }

    public void insertUserTicket(String assigneeName, String ticketId, Date createdDate) {
        try {
            MongoCollection<Document> collection = database.getCollection("user_tickets");
            Document userDoc = collection.find(Filters.eq("assigneeName", assigneeName)).first();
            if (userDoc == null) {
                userDoc = new Document("assigneeName", assigneeName);
                collection.insertOne(userDoc);
            }
            Document ticketDoc = new Document("ticketId", ticketId)
                    .append("createdDate", createdDate);
            collection.updateOne(Filters.eq("assigneeName", assigneeName),
                    new Document("$push", new Document("tickets", ticketDoc)));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error inserting user ticket: " + ticketId, e);
        }
    }

    public void insertTicketDetails(String ticketId, Map<String, Object> ticketDetails) {
        try {
            MongoCollection<Document> collection = database.getCollection("ticket_details");
            Document doc = new Document(ticketDetails);

            // Convert comments list to Document list
            if (ticketDetails.containsKey("comments")) {
                List<Map<String, String>> comments = (List<Map<String, String>>) ticketDetails.get("comments");
                List<Document> commentsDocs = new ArrayList<>();
                for (Map<String, String> comment : comments) {
                    commentsDocs.add(new Document(comment));
                }
                doc.append("comments", commentsDocs);
            }

            // Add description field if available
            if (ticketDetails.containsKey("description")) {
                doc.append("description", ticketDetails.get("description"));
            }

            collection.replaceOne(Filters.eq("ticketId", ticketId), doc, new ReplaceOptions().upsert(true));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error inserting ticket details: " + ticketId, e);
        }
    }

    public void updateUserLastUpdatedDate(String userId, Date currentDate) {
        try {
            MongoCollection<Document> usersCollection = database.getCollection("users");
            usersCollection.updateOne(Filters.eq("userId", userId),
                    new Document("$set", new Document("lastUpdatedDate", currentDate)));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error updating user last updated date: " + userId, e);
        }
    }
}

package com.example.FinalBaseline;

public class JiraSearchRequest {
    private final String project;
    private final String assignee;
    private final String createdDateStart;
    private final String createdDateEnd;
    private final int startAt;
    private final int maxResults;

    public JiraSearchRequest(String project, String assignee, String createdDateStart, String createdDateEnd, int startAt, int maxResults) {
        this.project = project;
        this.assignee = assignee;
        this.createdDateStart = createdDateStart;
        this.createdDateEnd = createdDateEnd;
        this.startAt = startAt;
        this.maxResults = maxResults;
    }

    public String getJql() {
        StringBuilder jql = new StringBuilder("project = " + project);

        if (assignee != null && !assignee.isEmpty()) {
            jql.append(" AND assignee = ").append(assignee);
        }

        if (createdDateStart != null && !createdDateStart.isEmpty() && createdDateEnd != null && !createdDateEnd.isEmpty()) {
            jql.append(" AND createdDate >= ").append(createdDateStart)
                    .append(" AND createdDate <= ").append(createdDateEnd);
        }

        return jql.toString();
    }

    public int getStartAt() {
        return startAt;
    }

    public int getMaxResults() {
        return maxResults;
    }
}

package com.example.FinalBaseline;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class JiraService {
    private static final int START_AT = 1500;
    private static final int MAX_RESULTS = 100;
    private static final String JIRA_URL = "";
    private static final String AUTH_HEADER = "";
    private static final Logger logger = LoggerFactory.getLogger(JiraService.class);

    @Autowired
    private JiraClient jiraClient;

    @Autowired
    private JiraResponseProcessor responseProcessor;

    @Autowired
    private ObjectMapper objectMapper;

    public void processJiraIssues() throws Exception {
        int startAt = START_AT;
        boolean moreResults = true;

        Set<Map<String, String>> uniqueUsers = new HashSet<>();
        Map<String, List<Map<String, Object>>> userTickets = new HashMap<>();

        while (moreResults) {
            JiraSearchRequest searchRequest = new JiraSearchRequest(
                    "", "", "2024-04-09", "2024-07-09", startAt, MAX_RESULTS);

            logger.info("Sending request with JQL: {}", searchRequest.getJql());

            HttpResponse<String> response = sendJiraRequest(searchRequest);

            logger.info("Received response: {}", response.body());

            moreResults = responseProcessor.processResponse(response, uniqueUsers, userTickets);
            startAt += MAX_RESULTS;
        }

        for (Map<String, String> user : uniqueUsers) {
            MongoConnection.insertUser(user.get("id"), user.get("name"), user.get("email"));
        }
    }

    private HttpResponse<String> sendJiraRequest(JiraSearchRequest searchRequest) throws Exception {
        String jsonRequestBody = String.format(
                "{ \"jql\": %s, \"startAt\": %d, \"maxResults\": %d }",
                objectMapper.writeValueAsString(searchRequest.getJql()),
                searchRequest.getStartAt(),
                searchRequest.getMaxResults()
        );

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(JIRA_URL))
                .header("Content-Type", "application/json")
                .header("Authorization", AUTH_HEADER)
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequestBody, StandardCharsets.UTF_8))
                .build();

        logger.info("Request Body: {}", jsonRequestBody);

        return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
    }
}
package com.example.FinalBaseline;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
public class BaselineController {

    @GetMapping("/fetchMyBaseline")
    public ResponseEntity<String> fetchMyBaseline(@RequestParam String name) {
        try {
            String encodedName = URLEncoder.encode(name, StandardCharsets.UTF_8.toString());
            String pythonServerUrl = "http://localhost:8081/fetchBaseline?name=" + encodedName;
            RestTemplate restTemplate = new RestTemplate();
            String response = restTemplate.getForObject(pythonServerUrl, String.class);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error generating baseline: " + e.getMessage());
        }
    }
}
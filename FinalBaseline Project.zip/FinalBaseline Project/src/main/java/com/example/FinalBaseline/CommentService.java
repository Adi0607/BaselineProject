package com.example.FinalBaseline;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class CommentService {

    @Value("${jira.base_url}")
    private String URL;

    @Value("${jira.username}")
    private String USERNAME;

    @Value("${jira.api_token}")
    private String API_TOKEN;

    private final ObjectMapper objectMapper;

    public CommentService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public List<Map<String, String>> fetchComments(String issueKey) throws Exception {
        String auth = Base64.getEncoder().encodeToString((USERNAME + ":" + API_TOKEN).getBytes(StandardCharsets.UTF_8));
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL + "/rest/api/3/issue/" + issueKey + "/comment"))
                .header("Authorization", "Basic " + auth)
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Check if the response is JSON
        if (isJsonResponse(response.body())) {
            return parseComments(response.body());
        } else {
            // Handle non-JSON response
            throw new Exception("Non-JSON response received: " + response.body());
        }
    }

    private List<Map<String, String>> parseComments(String responseBody) throws Exception {
        List<Map<String, String>> comments = new ArrayList<>();
        JsonNode rootNode = objectMapper.readTree(responseBody);
        JsonNode commentsNode = rootNode.path("comments");

        for (JsonNode commentNode : commentsNode) {
            Map<String, String> comment = new HashMap<>();
            comment.put("author", commentNode.path("author").path("displayName").asText());
            comment.put("body", commentNode.path("body").asText());
            comments.add(comment);
        }

        return comments;
    }

    private boolean isJsonResponse(String responseBody) {
        try {
            objectMapper.readTree(responseBody);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

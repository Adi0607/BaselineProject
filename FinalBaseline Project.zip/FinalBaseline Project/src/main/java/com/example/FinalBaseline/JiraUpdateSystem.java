package com.example.FinalBaseline;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class JiraUpdateSystem {
    private static final Logger logger = Logger.getLogger(JiraUpdateSystem.class.getName());

    @Autowired
    private JiraService jiraService;

    @Autowired
    private MongoConnection mongoConnection;

    // 1. Scheduled update
    @Scheduled(fixedRate = 24 * 60 * 60 * 1000) // Run every 24 hours
    public void updateAllUsers() {
        logger.info("Starting scheduled update of all users");
        try {
            jiraService.processJiraIssues();
            logger.info("Scheduled update completed successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error updating all users", e);
        }
    }

    // 2. Manual update method (can be called from a controller if needed)
    public void manualUpdate() {
        logger.info("Starting manual update of all users");
        try {
            jiraService.processJiraIssues();
            logger.info("Manual update completed successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in manual update of all users", e);
        }
    }

    // 3. Update last updated date
    public void updateLastUpdatedDate(String userId) {
        Date currentDate = new Date();
        logger.info("Updating last updated date for user " + userId + " to " + currentDate);
        try {
            // Assuming you have a method in MongoConnection to update the last updated date
            mongoConnection.updateUserLastUpdatedDate(userId, currentDate);
            logger.info("Last updated date successfully updated for user " + userId);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error updating last updated date for user " + userId, e);
        }
    }
}

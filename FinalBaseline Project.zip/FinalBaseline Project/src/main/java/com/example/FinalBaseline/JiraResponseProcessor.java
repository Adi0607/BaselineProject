package com.example.FinalBaseline;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class JiraResponseProcessor {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    private static final Logger logger = LoggerFactory.getLogger(JiraResponseProcessor.class);

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CommentService commentService;

    @Autowired
    private MongoConnection mongoConnection;

    public boolean processResponse(HttpResponse<String> response, Set<Map<String, String>> uniqueUsers, Map<String, List<Map<String, Object>>> userTickets) {
        try {
            // Check if the response is valid JSON
            if (isValidJson(response.body())) {
                JsonNode rootNode = objectMapper.readTree(response.body());
                JsonNode issuesNode = rootNode.path("issues");

                boolean moreResults = issuesNode.size() == 100;

                for (JsonNode issueNode : issuesNode) {
                    Map<String, Object> ticket = extractTicketDetails(issueNode);

                    List<Map<String, String>> comments = commentService.fetchComments(issueNode.path("key").asText());
                    ticket.put("comments", comments);

                    String ticketId = (String) ticket.get("ticketId");
                    String assigneeId = (String) ticket.get("assigneeId");
                    String assigneeName = (String) ticket.get("assignee");
                    String assigneeEmail = (String) ticket.get("assigneeEmail");
                    Date createdDate = (Date) ticket.get("createdDate");

                    mongoConnection.insertTicketDetails(ticketId, ticket);
                    mongoConnection.insertUserTicket(assigneeName, ticketId, createdDate);

                    Map<String, String> assigneeInfo = new HashMap<>();
                    assigneeInfo.put("name", assigneeName);
                    assigneeInfo.put("email", assigneeEmail);
                    assigneeInfo.put("id", assigneeId);
                    uniqueUsers.add(assigneeInfo);

                    Map<String, Object> ticketInfo = new HashMap<>();
                    ticketInfo.put("ticketId", ticketId);
                    ticketInfo.put("createdDate", createdDate);

                    userTickets.computeIfAbsent(assigneeId, k -> new ArrayList<>()).add(ticketInfo);

                    logger.info("Ticket ID: " + ticketId);
                    logger.info("Assignee: " + assigneeName);
                    logger.info("Assignee Email: " + assigneeEmail);
                    logger.info("Reporter: " + ticket.get("reporter"));
                    if (ticket.containsKey("parentTicket")) {
                        logger.info("Parent Ticket: " + ticket.get("parentTicket"));
                    }
                    if (ticket.containsKey("subtasks")) {
                        logger.info("Subtasks: " + ticket.get("subtasks"));
                    }
                    logger.info("Created Date: " + createdDate);
                    logger.info("Status: " + ticket.get("status"));
                    logger.info("Priority: " + ticket.get("priority"));
                    logger.info("Issue Type: " + ticket.get("issueType"));
                    logger.info("Description: " + ticket.get("description"));
                }

                return moreResults;
            } else {
                logger.error("Invalid JSON response: " + response.body());
                return false;
            }
        } catch (Exception e) {
            logger.error("Error processing response", e);
            return false;
        }
    }

    private boolean isValidJson(String responseBody) {
        try {
            objectMapper.readTree(responseBody);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private Map<String, Object> extractTicketDetails(JsonNode issueNode) throws Exception {
        Map<String, Object> ticket = new HashMap<>();
        ticket.put("ticketId", issueNode.path("key").asText());
        ticket.put("user", issueNode.path("fields").path("creator").path("displayName").asText());
        ticket.put("assignee", issueNode.path("fields").path("assignee").path("displayName").asText());
        ticket.put("assigneeEmail", issueNode.path("fields").path("assignee").path("emailAddress").asText());
        ticket.put("assigneeId", issueNode.path("fields").path("assignee").path("accountId").asText());
        ticket.put("reporter", issueNode.path("fields").path("reporter").path("displayName").asText());

        if (issueNode.path("fields").has("parent")) {
            ticket.put("parentTicket", issueNode.path("fields").path("parent").path("key").asText());
        }

        List<String> subtasks = new ArrayList<>();
        issueNode.path("fields").path("subtasks").forEach(subtask -> subtasks.add(subtask.path("key").asText()));
        ticket.put("subtasks", subtasks);

        ticket.put("createdDate", DATE_FORMAT.parse(issueNode.path("fields").path("created").asText()));
        ticket.put("status", issueNode.path("fields").path("status").path("name").asText());
        ticket.put("priority", issueNode.path("fields").path("priority").path("name").asText());
        ticket.put("issueType", issueNode.path("fields").path("issuetype").path("name").asText());
        ticket.put("description", issueNode.path("fields").path("description").asText());

        return ticket;
    }
}
